<?php


class Application_Model_Entities_Groupes extends Zend_Db_Table_Abstract {

    protected $_name = 'groupes';
    protected $_primary = 'ID_GROUPE'; 

}


<?php


class Application_Model_Entities_TypeEquipement extends Zend_Db_Table_Abstract {

    protected $_name = 'type_equipement';
    protected $_primary = 'id_type'; 

}


<?php 

class Application_Model_Entities_Client extends Zend_Db_Table_Abstract {

    protected $_name = 'client';
    protected $_primary = 'id_client'; 
  
    }

<?php


class Application_Model_Entities_Administrateurs extends Zend_Db_Table_Abstract {

    protected $_name = 'administrateurs';
    protected $_primary = 'ID_ADMIN'; 

}


<?php

class Application_Model_Entities_Equipement extends Zend_Db_Table_Abstract {

    protected $_name = 'equipement';
    protected $_primary = 'id_equipement'; 
    
}
<?php

class Application_Model_Entities_Certificat extends Zend_Db_Table_Abstract {

    protected $_name = 'certificat';
    protected $_primary = 'id_certificat'; 

}

?>